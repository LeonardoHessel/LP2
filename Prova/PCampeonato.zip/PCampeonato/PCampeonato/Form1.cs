﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCampeonato
{
    public partial class frmCampeonato : Form
    {
        public frmCampeonato()
        {
            InitializeComponent();
        }

        private void btnLerTimes_Click(object sender, EventArgs e)
        {
            // RA: 3

            int x = 3;
            int y = 3;

            int melhorSaldo = 0;
            int piorSaldo = 0;

            List<int> melhores = new List<int>();
            List<int> piores = new List<int>();

            int[,] gt = new int[x, y];
            
            string ax;
            for (int i = 0; i < x; i++)
            {
                do
                {
                    string msg = "Insira os gols feitos pelo time " + (i + 1);
                    ax = Interaction.InputBox(msg, "Insira os gols do time!");
                } while (!int.TryParse(ax, out gt[i,0]));

                do
                {
                    string msg = "Insira os gols recebidos pelo time " + (i + 1);
                    ax = Interaction.InputBox(msg, "Insira os gols do time!");
                } while (!int.TryParse(ax, out gt[i, 1]));

                int saldo = gt[i, 0] + (gt[i, 1] * -1);
                gt[i, 2] = saldo;
                lstbxTimes.Items.Add("Time: " + (i + 1) + " Gols feitos: " + gt[i, 0] + " Gols recebidos: " + gt[i, 1] + " Saldo de Gols: " + gt[i, 2]);


                if (i == 0)
                {
                    melhorSaldo = saldo;
                    piorSaldo = saldo;
                    melhores.Add(i+1);
                    piores.Add(i+1);
                }
                else
                {
                    if (saldo > melhorSaldo)
                    {
                        melhorSaldo = saldo;
                        melhores.Clear();
                        melhores.Add(i+1);
                    }
                    else if (saldo == melhorSaldo)
                    {
                        melhorSaldo = saldo;
                        melhores.Add(i+1);
                    }
                    else if (saldo < piorSaldo)
                    {
                        piorSaldo = saldo;
                        piores.Clear();
                        piores.Add(i+1);
                    }
                    else if (saldo == piorSaldo)
                    {
                        piorSaldo = saldo;
                        piores.Add(i+1);
                    }
                }
            }
            lstbxTimes.Items.Add("______________________________________________");

            string pioresStr = "";
            for (int i = 0; i < piores.Count; i++)
            {
                pioresStr += " Time " + piores[i];
                if (!(i + 1 == piores.Count)) pioresStr += " e ";
            }

            string melhoresStr = "";
            for (int i = 0; i < melhores.Count; i++)
            {
                melhoresStr += " Time " + melhores[i];
                if (!(i + 1 == melhores.Count)) melhoresStr += " e ";
            }

            lstbxTimes.Items.Add("Pior(es) Time(s):" + pioresStr + " Pior(es) Saldo(s) de Gols: " + piorSaldo);

            lstbxTimes.Items.Add("Melhor(es) Time(s):" + melhoresStr + " Melhor(es) Saldo(s) de Gols: " + melhorSaldo);

        }
    }
}
