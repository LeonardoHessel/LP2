﻿namespace PCampeonato
{
    partial class frmCampeonato
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLerTimes = new System.Windows.Forms.Button();
            this.lstbxTimes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnLerTimes
            // 
            this.btnLerTimes.Location = new System.Drawing.Point(499, 155);
            this.btnLerTimes.Name = "btnLerTimes";
            this.btnLerTimes.Size = new System.Drawing.Size(122, 70);
            this.btnLerTimes.TabIndex = 1;
            this.btnLerTimes.Text = "LerTimes";
            this.btnLerTimes.UseVisualStyleBackColor = true;
            this.btnLerTimes.Click += new System.EventHandler(this.btnLerTimes_Click);
            // 
            // lstbxTimes
            // 
            this.lstbxTimes.FormattingEnabled = true;
            this.lstbxTimes.Location = new System.Drawing.Point(12, 12);
            this.lstbxTimes.Name = "lstbxTimes";
            this.lstbxTimes.Size = new System.Drawing.Size(436, 394);
            this.lstbxTimes.TabIndex = 2;
            // 
            // frmCampeonato
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 416);
            this.Controls.Add(this.lstbxTimes);
            this.Controls.Add(this.btnLerTimes);
            this.Name = "frmCampeonato";
            this.Text = "Campeonato";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLerTimes;
        private System.Windows.Forms.ListBox lstbxTimes;
    }
}

